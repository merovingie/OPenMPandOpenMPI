#include "gtmp.h"
#include "gtmpi.h"

void combined_init(int num_processes, int num_threads)
{
    gtmpi_init(num_processes);
    gtmp_init(num_threads);
    
}

void combined_barrier()
{
    gtmpi_barrier();
    gtmp_barrier();
}

void combined_finalize()
{
    gtmpi_finalize();
    gtmp_finalize();
}
