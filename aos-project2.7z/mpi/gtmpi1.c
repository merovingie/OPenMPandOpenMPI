#include<math.h>
#include <stdlib.h>
#include <mpi.h>
#include <stdio.h>
#include "gtmpi.h"
#include <sys/time.h>
#include <stdbool.h>
#include<syslog.h>

#define NUM_BARRIERS 1000


int size = -1;
int rank = -1;
char hostName[100];
int len;

int numThreads;

bool logging = true;

double timeduration(struct timeval t1, struct timeval t2)
{
	return (t2.tv_sec-t1.tv_sec)*1000000+(t2.tv_usec-t1.tv_usec);
}

void gtmpi_init(int num_threads){
	numThreads = num_threads;
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	MPI_Comm_rank(MPI_COMM_WORLD,&rank);
	MPI_Get_processor_name(hostName, &len);

}

void gtmpi_barrier(){
	if(logging){
		openlog("OPENMPI_LOG1", LOG_NDELAY| LOG_PID |LOG_CONS, LOG_USER);
		syslog(LOG_DEBUG, "This MPI1 Host %s\t Process %d\t Size of world %d!\n", hostName, rank, size);
		closelog();
	}
	int i, to_send, msg =1, tag=1, to_recv;
	MPI_Status status;
	int num_levels = ceil(log(numThreads)/log(2));

	for(i=0; i<num_levels; i++){
		to_send = (rank + pow(2, i));
		to_send = to_send % numThreads;

		to_recv = (rank - pow(2, i) + numThreads);
		to_recv = to_recv %  numThreads;

		MPI_Send(&msg, 1, MPI_INT, to_send, tag, MPI_COMM_WORLD);
		MPI_Recv(&msg, 1, MPI_INT, to_recv, tag, MPI_COMM_WORLD, &status);
		if(logging){
			openlog("OPENMPI_LOG1", LOG_NDELAY| LOG_PID |LOG_CONS, LOG_LOCAL1);
			syslog(LOG_DEBUG, "MPI1 process %d received value %d from rank %d, with tag %d and error code %d.\n", rank, msg, status.MPI_SOURCE, status.MPI_TAG,status.MPI_ERROR);
			closelog();
		}
	}
}

void gtmpi_finalize(){}
